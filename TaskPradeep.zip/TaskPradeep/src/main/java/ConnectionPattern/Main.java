package ConnectionPattern;

import ConnectionPattern.GetConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import ConnectionPattern.GetObject;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.*;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);
    public static void main(String[] args) throws Exception {
        String str=args[0];
        GetConnection gc=GetObject.getObject(str);
        Connection c=gc.getConnect(str);
    }
}
