package ConnectionPattern;

import ConnectionPattern.GetConnection;

public class GetObject {
       static GetConnection getObject(String str){
           if(str.contains("config2.json")){
               return new MongoDB();
           }
           if(str.contains("config.json")){
               return new Postgresql();
           }
               return null;
       }
}
