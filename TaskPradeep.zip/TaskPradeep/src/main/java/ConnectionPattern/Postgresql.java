package ConnectionPattern;

import ConnectionPattern.Connection1;
import ConnectionPattern.GetConnection;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;
public class Postgresql implements GetConnection {
    public Connection getConnect(String path) throws SQLException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
        Connection1 c = new Connection1();
        return (Connection) c.getConnectionPostgreSQL(path);
    }
}
