package ConnectionPattern;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.*;
import java.util.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import com.mongodb.MongoCredential;

public class Connection1 {
    private static final Logger logger = LogManager.getLogger(Connection1.class);
    public static Connection getConnectionPostgreSQL(String path) throws SQLException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        EncryptDecrypt e=new EncryptDecrypt();
        JSONParser jp = new JSONParser();
        Connection con;
        JSONObject jo = null;
        try {
            jo = (JSONObject) jp.parse(new FileReader(path));
            String uname = (String) jo.get("username");
            String pwd = (String) jo.get("password");
            String passwd = e.decode(pwd);
            String url = (String) jo.get("url");
            con = (Connection) DriverManager.getConnection(url, uname, passwd);
            logger.info("Connection established");
            return con;
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } catch (ParseException ex) {
            throw new RuntimeException(ex);
        } catch (InvalidKeySpecException ex) {
            throw new RuntimeException(ex);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    public static MongoClient getConnectionMongoDB(String path) throws Exception {
        JSONParser jp = new JSONParser();
        JSONObject jo = null;
        try {
            jo = (JSONObject) jp.parse(new FileReader(path));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        EncryptDecrypt e=new EncryptDecrypt();
        String host = (String) jo.get("host");
        Long port = (Long) jo.get("port");
        String username = (String) jo.get("username");
        String databaseName = (String) jo.get("database");
        String password =  e.decode((String)jo.get("password"));
        try {
            MongoClient db = new MongoClient(host, Math.toIntExact(port));
            MongoCredential credential;
            credential = MongoCredential.createCredential(username, databaseName, password.toCharArray());
            logger.info("Successfully Connected  to the database");
            MongoDatabase database = db.getDatabase("training_2022");
            logger.info("Credentials are: " + credential);
            database.createCollection("sampleCollection");
            logger.info("Collection created Successfully");
            return db;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

}
