package ConnectionPattern;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.security.KeyPairGenerator;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.*;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
public class CreatePrivatePuiblicKeys {
    void create() {
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(512);
            KeyPair kp = kpg.generateKeyPair();
            PrivateKey aPrivate = kp.getPrivate();
            PublicKey aPublic = kp.getPublic();
            try {
                FileOutputStream outPrivate = new FileOutputStream("key.priv");
                outPrivate.write(aPrivate.getEncoded());
                FileOutputStream outPublic = new FileOutputStream("key.pub");
                outPublic.write(aPublic.getEncoded());
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
