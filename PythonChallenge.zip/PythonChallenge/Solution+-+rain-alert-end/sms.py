#Note! For the code to work you need to replace all the placeholders with
#Your own details. e.g. account_sid, lat/lon, from/to phone numbers.

import requests
import os
from twilio.rest import Client
from twilio.http.http_client import TwilioHttpClient

account_sid = "ACc73178e33b60921d8dea5e01bb8b3fdd"
auth_token = "a0de915362aa0c08cc5a28d243218b36"

client = Client(account_sid, auth_token)
message = client.messages.create(
  from_='+18149759917',
  body='hloo',
  to='+919154027027'
)
print(message.status)





