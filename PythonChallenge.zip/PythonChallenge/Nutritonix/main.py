import requests
from datetime import datetime
import os

GENDER = "female"
WEIGHT_KG = 45
HEIGHT_CM = 5.3
AGE =  22

exercise_endpoint = "https://trackapi.nutritionix.com/v2/natural/exercise"
exercise_text = input("Tell me which exercises you did: ")

headers = {
    "x-app-id": os.environ.get("APP_ID"),
    "x-app-key": os.environ.get("API_KEY")
}

parameters = {
    "query": exercise_text,
    "gender": GENDER,
    "weight_kg": WEIGHT_KG,
    "height_cm": HEIGHT_CM,
    "age": AGE
}

sheet_endpoint = "https://api.sheety.co/2c35d47f36ffbb3474b0407f86328c7c/sanjuWorkout/sheet1"


response=requests.post(url = exercise_endpoint,headers=headers,json=parameters)
response.raise_for_status()
result=response.json()
print(result)


today_date = datetime.now().strftime("%d/%m/%Y")
now_time = datetime.now().strftime("%X")

for exercise in result["exercises"]:
    sheet_inputs = {
        "sheet1": {
            "date": today_date,
            "time": now_time,
            "exercise": exercise["name"].title(),
            "duration": exercise["duration_min"],
            "calories": exercise["nf_calories"]
        }
    }

headers_ss = {"Authorization": os.environ.get("TOKEN")}

sheet_response = requests.post(sheet_endpoint, json=sheet_inputs,headers=headers_ss)

print(sheet_response.text)

# Basic Authentication
# sheet_response = requests.post(
#     sheet_endpoint,
#     json=sheet_inputs,
#     auth=(
#         YOUR USERNAME,
#     YOUR PASSWORD,
#     )
# )

