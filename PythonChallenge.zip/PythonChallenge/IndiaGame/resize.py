from PIL import Image

# Open the image
image_path = "/home/sp1409/Desktop/WorkArea/pythonProjects/PythonChallenge/IndiaGame/india-locator-map-blank.jpg"  # Replace with the actual path to your image
original_image = Image.open(image_path)

# Define the desired dimensions for the resized image
new_width = 550  # Replace with the desired width in pixels
new_height = 576  # Replace with the desired height in pixels

# Resize the image
resized_image = original_image.resize((new_width, new_height))

# Save the resized image to a new file
resized_image_path = "path_to_resized_image.jpg"  # Replace with the desired path for the resized image
resized_image.save(resized_image_path)

# Display a message indicating that the image has been resized and saved
print(f"Image resized and saved to {resized_image_path}")