import smtplib

myemail="sanjanareddypeddi989@gmail.com"
password='gfktyeodmmhlabca'

connection=smtplib.SMTP("smtp.gmail.com")
connection.starttls()
connection.login(user=myemail,password=password)
connection.sendmail(from_addr=myemail,
                        to_addrs="sanjanareddypeddi989@gmail.com",
                        msg="Subject: Hello \n\n How are you")
connection.close()