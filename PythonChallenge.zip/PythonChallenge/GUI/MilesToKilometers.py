from tkinter import *

#Creating a new window and configurations
window = Tk()
window.title("Miles to km")
window.minsize(width=500, height=500)

def action():
    input_miles= input.get()
    km=int(input_miles)*1000
    label = Label(text=f"{km} km")
    label.grid(columns=4,row=4)

#calls action() when pressed
button = Button(text="Click Me", command=action)
button.grid(column=1, row=0)

input = Entry(width=10)
input.grid(column=3, row=2)






window.mainloop()
