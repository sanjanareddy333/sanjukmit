
import requests
parameters = {
       "lat" : "18.781180",
       "lon" : "78.850948",
        "appid" : "9c539bfeb0796f860a49f94e4f75cae9"
    }

respone=requests.get("https://pro.openweathermap.org/data/2.5/forecast/hourly",params=parameters)
respone.raise_for_status()
question_data=respone.json()["results"]
