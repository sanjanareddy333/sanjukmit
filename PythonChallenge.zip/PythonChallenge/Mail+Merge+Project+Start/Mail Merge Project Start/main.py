with open("/home/sp1409/Desktop/WorkArea/pythonProjects/PythonChallenge/Mail+Merge+Project+Start/Mail Merge Project Start/Input/Names/invited_names.txt") as file:
    contents=file.readlines()
with open("/home/sp1409/Desktop/WorkArea/pythonProjects/PythonChallenge/Mail+Merge+Project+Start/Mail Merge Project Start/Input/Letters/starting_letter.txt") as file_read:
    content = file_read.read()
    content.strip()
    for each_content in contents:
        with open(f"/home/sp1409/Desktop/WorkArea/pythonProjects/PythonChallenge/Mail+Merge+Project+Start/Mail Merge Project Start/Output/ReadyToSend/letter_for_{each_content}",'w') as file_write:
            file_write.write(content.replace("[name]",each_content))
