import tkinter as tk
from tkinter import PhotoImage

def on_button_click():
    print("Button clicked!")

root = tk.Tk()
root.title("Image Button Example")

image = PhotoImage(file="images/right.png")  # Replace "image.png" with the actual path to your image

button = tk.Button(root, image=image, command=on_button_click)
button.pack()

root.mainloop()
