from tkinter import *
import pandas
import math

# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def passwordGenerator():
    # Password Generator Project
    import random
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
               'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']
    password_list=[random.choice(letters) for i in range(random.randint(8,10))]
    password_list += [random.choice(symbols) for i in range(random.randint(2,4))]
    password_list += [random.choice(numbers) for i in range(random.randint(2,4))]

    random.shuffle(password_list)

    password = ""
    for char in password_list:
        password += char
    print(f"Your password is: {password}")
    return password


# ---------------------------- SAVE PASSWORD ------------------------------- #
def save_password():
    mail=entry1.get()
    username=entry2.get()
    password=entry3.get()
    data=[]
    data.append(mail)
    data.append(username)
    data.append(password)
    new_data = pandas.DataFrame(data)
    new_data.to_csv("states_to_learn.csv",sep='|')


# ---------------------------- UI SETUP ------------------------------- #



window = Tk()
window.title("password manager")
window.config(padx=20, pady=20)

canvas = Canvas(width=200, height=200, highlightthickness=0)
tomato_img = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=tomato_img)
canvas.grid(column=1, row=1)

label1=Label(text="mail : ")
label1.grid(column=0, row=2)
label2=Label(text="usernmae : ")
label2.grid(column=0, row=3)
label3=Label(text="password : ")
label3.grid(column=0, row=4)


entry1 = Entry(width=40)
entry1.grid(column=1,row=2,columnspan=2)
entry2 = Entry(width=40)
entry2.grid(column=1,row=3,columnspan=2)
entry3 = Entry(width=20)
entry3.grid(column=1,row=4,columnspan=1)

def Generate():
    password=passwordGenerator()
    entry3.insert(END,password)
generate_password=Button(text="genenrate_password",command=Generate)
generate_password.grid(column=2,row=4)
add=Button(text="add",command=save_password)
add.grid(column=1,row=5)


window.mainloop()
