package ProducerAndConsumer;

import com.modak.utils.HashMapUtils;
import com.modak.utils.StringTemplateUtils;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class MethodInitialization {
    //This method was used to set properties it takes input the hashmap which has details of produce and consumer
   public static Properties setProperties(HashMap<String,Object> propertiesToSetMap,String propertiesKeyName) throws IOException {
        HashMap<String, Object> propertiesMap = HashMapUtils.getMap(propertiesToSetMap, propertiesKeyName);
        //Create a object for Properties
        Properties properties = new Properties();
        //All properties were set
        properties.putAll(propertiesMap);
        //consumer was created
        return properties;
    }
    //This method was used to render the template it takes input a hashmap which has  details of producer and consumer
    public static String renderTemplate(HashMap<String,Object> messageTemplateDetailsMap){
        return StringTemplateUtils.renderTemplate(
                HashMapUtils.getString(messageTemplateDetailsMap, ConstantClass.TEMPLATE_GROUP),
                HashMapUtils.getString(messageTemplateDetailsMap, ConstantClass.TEMPLATE_NAME), new HashMap<>());
    }
}
