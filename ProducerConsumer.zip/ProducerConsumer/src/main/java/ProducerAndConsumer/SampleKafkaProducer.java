package ProducerAndConsumer;

import com.modak.utils.HashMapUtils;
import com.modak.utils.JSONUtils;
import com.modak.utils.compression.ByteArrayCompression;
import com.modak.utils.encryption.EncryptionUtils;
import com.modak.utils.encryption.RSAEncryptionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Properties;

public class SampleKafkaProducer {
        public static void main(String args[]) throws Exception {
                //By using Modak utils to read file and converting JsonString into HashMap
                HashMap<String, Object> producerDetailsMap = JSONUtils.jsonToMap(FileUtils.readFileToString(new File(args[0]), StandardCharsets.UTF_8));
                //Rendered the template and stored it in String by using renderTemplates() method of  MethodInitialization class
                HashMap<String, Object> messageTemplateMap = HashMapUtils.getMap(producerDetailsMap, ConstantClass.MESSAGE_TEMPLATE);
                String message = MethodInitialization.renderTemplate(messageTemplateMap);
                //setProperties() was a method defined in MethodInitialization class for setting all properties
                Properties properties = MethodInitialization.setProperties(producerDetailsMap,ConstantClass.PRODUCER_PROPERTIES);
                //Getting public key by using Modak Utils using getPublicKey() method
                PublicKey publicKey=  RSAEncryptionUtils.getPublicKey(HashMapUtils.getString(producerDetailsMap,ConstantClass.PUBLIC_KEY_PATH));
                //compression of message using compressUsingZip
                byte compressMessageBytes[]= ByteArrayCompression.compressUsingGZIP(message.getBytes());
                 //encrypt the compressed message
                byte encryptedMessageBytes[] = EncryptionUtils.encryptLargeByteArrayUsingRSA(compressMessageBytes,publicKey);
                //created a producer
                KafkaProducer<String, byte[]> producer = new KafkaProducer<String, byte[]>(properties);
                //Creation of a producer record
                ProducerRecord<String, byte[]> record = new ProducerRecord<String, byte[]>(HashMapUtils.getString(producerDetailsMap, ConstantClass.TOPIC_NAME), encryptedMessageBytes);
                //Sending the records
                producer.send(record);
                producer.flush();
                producer.close();
        }

}