package ProducerAndConsumer;

public class ConstantClass {
        public static  String PRIVATE_KEY_PATH = "private_key_path";
        public static  String PUBLIC_KEY_PATH = "public_key_path";
        public static String TOPIC_NAME= "topic_name";
        public static String  CLASS_NAME = "class_name";
        public static String  TEMPLATE_GROUP = "template_group";
        public static String  TEMPLATE_NAME= "template_name";
        public static String  CONSUMER_PROPERTIES="consumer_properties";
        public static String  PRODUCER_PROPERTIES="producer_properties";
        public static String DURATION="duration";
        public static String MESSAGE_TEMPLATE="message_template";
}
