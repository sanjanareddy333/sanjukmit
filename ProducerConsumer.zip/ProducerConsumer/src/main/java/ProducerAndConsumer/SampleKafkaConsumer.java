    package ProducerAndConsumer;

    import com.modak.utils.HashMapUtils;
    import com.modak.utils.JSONUtils;
    import com.modak.utils.compression.ByteArrayCompression;
    import com.modak.utils.encryption.EncryptionUtils;
    import com.modak.utils.encryption.RSAEncryptionUtils;
    import org.apache.commons.io.FileUtils;
    import org.apache.kafka.clients.consumer.ConsumerRecord;
    import org.apache.kafka.clients.consumer.ConsumerRecords;
    import org.apache.kafka.clients.consumer.KafkaConsumer;
    import org.slf4j.Logger;
    import org.slf4j.LoggerFactory;
    import java.io.File;
    import java.nio.charset.StandardCharsets;
    import java.security.PrivateKey;
    import java.time.Duration;
    import java.util.Arrays;
    import java.util.HashMap;
    import java.util.Properties;

    public class SampleKafkaConsumer {
        public static void main(String[] args) throws Exception {
            //By using Modak utils to read file and converting JsonString into HashMap
            HashMap<String, Object> consumerDetailsMap = JSONUtils.jsonToMap(FileUtils.readFileToString(new File(args[0]), StandardCharsets.UTF_8));
            //Logger object was created
            Logger logger= LoggerFactory.getLogger(HashMapUtils.getString(consumerDetailsMap,ConstantClass.CLASS_NAME));
            //PrivateKey was generated for decryption of code
            PrivateKey privateKey=  RSAEncryptionUtils.getPrivateKey(HashMapUtils.getString(consumerDetailsMap,ConstantClass.PRIVATE_KEY_PATH));
            //setProperties() was a method defined in MethodInitialization class for setting all properties
            Properties properties =MethodInitialization.setProperties(consumerDetailsMap,ConstantClass.CONSUMER_PROPERTIES);
            //consumer was created
            KafkaConsumer<String,byte[]> consumer=new KafkaConsumer<>(properties);
            //Consumer subscribed to a topic
            consumer.subscribe(Arrays.asList(HashMapUtils.getString(consumerDetailsMap,ConstantClass.TOPIC_NAME)));
            //The records were Consumed
            while(true) {
                //consumer reads data from Kafka through the polling method.
                ConsumerRecords<String,byte[]> records=consumer.poll(Duration.ofMillis((int)HashMapUtils.get(consumerDetailsMap,ConstantClass.DURATION)));
                for (ConsumerRecord<String, byte[]> record : records) {
                    //decrypting the message using decryptLargeByteArrayUsingRSA
                    byte[] decryptedMessageBytes= EncryptionUtils.decryptLargeByteArrayUsingRSA(record.value(),privateKey);
                    //uncompress the decrypted message
                    byte[] uncompressMessageBytes= ByteArrayCompression.uncompressUsingGZIP(decryptedMessageBytes);
                    logger.info(new String(uncompressMessageBytes));
                }
            }
        }
    }
