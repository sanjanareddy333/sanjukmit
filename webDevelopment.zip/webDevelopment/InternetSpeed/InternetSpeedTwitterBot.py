
class InternetSpeedTwitterBot():
    init()
