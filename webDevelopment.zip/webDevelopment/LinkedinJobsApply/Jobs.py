from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


chrome_driver_path = "/usr/local/bin/chromedriver"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)
chrome_options.add_argument(f"executable_path={chrome_driver_path}")
driver = webdriver.Chrome(options=chrome_options)
driver.get("https://www.linkedin.com/login")
username = "sanjanareddypeddi989@gmail.com"
password = "Sanju989$"
username_field = driver.find_element(By.ID,"username")
password_field = driver.find_element(By.ID,"password")

username_field.send_keys(username)
password_field.send_keys(password)
signup=driver.find_element(By.TAG_NAME,"button")
signup.click()
#
driver.get("https://www.linkedin.com/jobs/search/?currentJobId=3700644206&f_AL=true&keywords=python%20developer&origin=JOB_SEARCH_PAGE_JOB_FILTER&sortBy=R")