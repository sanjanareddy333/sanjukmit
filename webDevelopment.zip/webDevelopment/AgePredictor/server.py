import requests as requests
from flask import Flask, render_template
import requests

app = Flask(__name__)


@app.route("/")
def hello_world():
    return "<h1>hello</h1>"

@app.route("/guess/<name>")
def guess(name):
    gender_url=f"https://api.genderize.io?name={name}"
    respone = requests.get(gender_url)
    gender = respone.json()["gender"]
    age_url=f"https://api.agify.io?name={name}"
    respone2 = requests.get(age_url)
    age = respone2.json()["age"]
    return render_template("index.html", name=name, age=age, gender=gender)

if __name__ == "__main__":
    app.run(debug=True)



