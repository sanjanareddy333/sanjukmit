
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

chrome_driver_path = "/usr/local/bin/chromedriver"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)
chrome_options.add_argument(f"executable_path={chrome_driver_path}")
driver = webdriver.Chrome(options=chrome_options)
driver.get("http://secure-retreat-92358.herokuapp.com/")

fname=driver.find_element(By.NAME,"fName")
fname.send_keys("sanju")
lname=driver.find_element(By.NAME,"lName")
lname.send_keys("reddy")
mail=driver.find_element(By.NAME,"email")
mail.send_keys("sanjanareddy@gmail.com")
signup=driver.find_element(By.TAG_NAME,"button")
signup.click()


search_key.send_keys(Keys.ENTER)