from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

chrome_driver_path = "/usr/local/bin/chromedriver"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)
chrome_options.add_argument(f"executable_path={chrome_driver_path}")
driver = webdriver.Chrome(options=chrome_options)
driver.get("https://en.wikipedia.org/wiki/Main_Page")

element = driver.find_element(By.CSS_SELECTOR, "#articlecount a")
element_text = element.text
# element.click()

print(element_text)

all_portals=driver.find_element(By.LINK_TEXT,"Content portals")
# all_portals.click()
search_key=driver.find_element(By.NAME,"search")
search_key.send_keys("python")
search_key.send_keys(Keys.ENTER)

# Close the WebDriver when you're done
# driver.quit()
