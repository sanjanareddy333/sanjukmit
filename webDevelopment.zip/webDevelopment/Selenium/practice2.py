from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

# Deprecated - no longer needed

# keeps chrome open
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

# driver = webdriver.Chrome(executable_path=chrome_driver_path)
# driver = webdriver.Chrome()
driver = webdriver.Chrome()
driver.get("https://www.python.org/")
names = driver.find_element(By.XPATH,'//*[@id="content"]/div/section/div[2]/div[2]/div/h2/text()')
names.click()
print(names)

