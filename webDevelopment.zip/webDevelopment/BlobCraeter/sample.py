import requests

url = "https://www.npoint.io/docs/045b46dc585edc87c4f3"

try:
    response = requests.get(url)
    response.raise_for_status()  # Check for HTTP errors
    print(response.json())
except requests.exceptions.RequestException as e:
    print("Request error:", e)