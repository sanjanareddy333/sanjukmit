import spotipy
from spotipy.oauth2 import SpotifyClientCredentials, SpotifyOAuth

# Replace these with your own client ID and client secret
client_id = 'd07d0341d52440329f1a7814494ff2fe'
client_secret = 'f50aca905d5e414e8151c4ec6e5c9bb4'

# Create a Spotify client with client credentials flow
client_credentials_manager = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)

# Example: Get a playlist by its Spotify URI
playlist_uri = 'spotify:playlist:6pmbyDzwPkSXazgmcPA08C'
playlist = sp.playlist(playlist_uri)

# Print the playlist name
print("Playlist Name:", playlist['name'])



# You can now make various API calls using the 'sp' object
